def getHeaders():
    return {
        "Accept": "application/json"
    }
    